package starlock.manager;

public interface StarLockManager {
    String VERSION = "0.1-BETA";
    String[] Authors = {
            "YoungSmoke - Великий Уцы *он сам сказал так написать*",
            "_jvmti_ - Нативный Амбасадор и просто Снюс Man",
            "Paimon - Хочешь покажу фокус? - На тебе декрипт твоего клиента",
            "Loremaster - Я ТРАХНУ ТБЕЯ В ЖОПУ"
    };
}
