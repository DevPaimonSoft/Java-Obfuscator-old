package starlock.manager;

import lombok.NonNull;
import lombok.Setter;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.LdcInsnNode;
import starlock.Main;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.impl.number.MutationNumberTransformer;
import starlock.obfuscator.transformers.impl.ref.HeavyInvokeDynamic;
import starlock.obfuscator.transformers.impl.string.HeavyStringTransformer;
import starlock.utils.ASMHelper;
import starlock.utils.Utils;
import starlock.utils.wrapper.ClassWrapper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class FileManager extends Utils {
    public static List<ClassWrapper> LIBS = null;
    public static final Map<String,ClassWrapper> CLASSES = new ConcurrentHashMap<>();
    public static final Map<String, byte[]> ClassesBytes = new ConcurrentHashMap<>();
    public static final Map<String, byte[]> FILES = new ConcurrentHashMap<>();
    @Setter
    private static File inputFile,outputFile,path;

    public static void loadLibs(){
        LIBS = new ArrayList<>();
        for (File file : path.listFiles()) {
            if (!file.isDirectory()) {
                try {
                    ZipFile zipFile = new ZipFile(file);
                    zipFile.entries().asIterator().forEachRemaining(zipEntry -> {
                                try {
                                    var is = zipFile.getInputStream(zipEntry);
                                    var name = zipEntry.getName();
                                    var buffer = is.readAllBytes();

                                    if (isClassFile(name, buffer)) LIBS.add(new ClassWrapper(buffer));

                                    //if(name.endsWith(".class")){
                                    //    ClassesBytes.put(name, buffer);
                                    //}

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                    );
                } catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        }
    }
    public static void parseFile(){
        try {
            ZipFile zipFile = new ZipFile(inputFile);
            zipFile.entries().asIterator().forEachRemaining(zipEntry -> {
                        try {
                            var is = zipFile.getInputStream(zipEntry);
                            var name = zipEntry.getName();
                            var buffer = is.readAllBytes();

                            if (isClassFile(name, buffer)) CLASSES.put(name,new ClassWrapper(buffer));
                            else FILES.put(name, buffer);

                            //if(name.endsWith(".class")){
                            //    ClassesBytes.put(name, buffer);
                            //}

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
            );
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }
    public static void saveOutput() {
        try (ZipOutputStream zipFile = new ZipOutputStream(new FileOutputStream(outputFile))) {
            System.gc();
            CLASSES.forEach((name,wrapper) -> {
                try {
                    zipFile.putNextEntry(new ZipEntry(wrapper.getName() + ".class"));
                    /*if(wrapper.getName().equals(mainClass)){
                        zipFile.write(wrapper.write());
                    } else {*/
                    //String name = wrapper.getName();
                    byte[] toObf = classToBytes(wrapper.getClassNode());
                    //byte[] data = encrypt(toObf);
                    //byte[] data = new ClassEncryptorTransformer().obfuscate(toObf,name);
                    zipFile.write(toObf);
                    /* }*/
                    zipFile.closeEntry();
                } catch (Throwable throwable) {
                    // throwable.printStackTrace();
                }
            });
            FILES.forEach((name, buffer) -> {
                if (name.endsWith("/"))
                    return;
                try {
                    zipFile.putNextEntry(new ZipEntry(name));
                    zipFile.write(buffer);
                    zipFile.closeEntry();
                } catch (Throwable throwable) {
                    //throwable.printStackTrace();
                }
            });

            //TODO: save lib and replace values
            InputStream stream = Main.class.getResourceAsStream("/StarLock.class");
            ClassNode classNode = new ClassNode(Opcodes.ASM9);
            ClassReader reader = new ClassReader(stream);;
            reader.accept(classNode, Opcodes.ASM9);

            classNode.methods.forEach(methodNode -> {
                Arrays.stream(methodNode.instructions.toArray())
                        .forEach(insn -> {
                            if(ASMHelper.isInteger(insn) && ASMHelper.getInteger(insn) == 1122331334){
                                methodNode.instructions.set(insn, new LdcInsnNode(MutationNumberTransformer.key));
                            } else if(ASMHelper.isInteger(insn) && ASMHelper.getInteger(insn) == 345345777){
                                methodNode.instructions.set(insn, new LdcInsnNode(HeavyStringTransformer.key2));
                            } else if(ASMHelper.isString(insn) && ASMHelper.getString(insn).equals("SPLITSTRING")){
                                methodNode.instructions.set(insn, new LdcInsnNode(HeavyInvokeDynamic.spliter));
                            }
                        });
                if(methodNode.invisibleAnnotations == null){
                    methodNode.invisibleAnnotations = new ArrayList<>();
                }
                methodNode.localVariables = null;
                methodNode.invisibleAnnotations.add(new AnnotationNode("StarLock(NativeTransformer)"));
                methodNode.invisibleAnnotations.contains(new AnnotationNode("StarLock(NativeTransformer)"));
            });

            zipFile.putNextEntry(new ZipEntry(classNode.name + ".class"));
            zipFile.write(classToBytes(classNode));
            zipFile.closeEntry();

            System.gc();
        } catch (IOException e) {
            // e.printStackTrace();
        }
    }
}
