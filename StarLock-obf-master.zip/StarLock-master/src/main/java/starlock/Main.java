package starlock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import starlock.manager.FileManager;
import starlock.manager.StarLockManager;
import starlock.obfuscator.Obfuscator;
import org.apache.commons.cli.*;
import java.io.File;
import java.util.*;

public class Main extends FileManager implements StarLockManager {
    protected static final Logger LOGGER = LogManager.getLogger("StarLock");

    public static void main(String[] args) {
        preStart();

        CommandLineParser parser = new DefaultParser();
        try {
            CommandLine cmd = parser.parse(getOptions(), args);
            if(cmd.hasOption("libs")) {
                LOGGER.info("    Loading libs....");
                setPath(new File(cmd.getOptionValue("libs")));
                loadLibs();
                LOGGER.info("    Loaded!\n");
            }

            if(cmd.hasOption("input")) {
                setInputFile(new File(cmd.getOptionValue("input")));
            } else throw new RuntimeException("Input has null!");

            if(cmd.hasOption("output")) {
                setOutputFile(new File(cmd.getOptionValue("output")));
            } else throw new RuntimeException("Output has null!");

            if(cmd.hasOption("config")) {
                loadCFG(cmd.getOptionValue("config"));
            } else {
                if(!new File("config.yml").exists()) saveCFG();
                loadCFG("config.yml");
            }

        } catch (ParseException e) {
            System.err.println("Cannot parse command line.");
            throw new RuntimeException(e);
        }

        parseFile();
        new Obfuscator().run();
        saveOutput();
    }
    private static int getLen(String str){
        int ban = ("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =".length());
        return (ban - str.length());
    }
    private static void preStart(){
        String version = StarLockManager.VERSION;
        int forRepeat = (getLen(version) - "                               ".length());
        LOGGER.info("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
        LOGGER.info("=                     StarLock LTD                        =");
        LOGGER.info("=            StarLock - New Modern Protection             =");
        LOGGER.info("=                   Version: "+version+" ".repeat(forRepeat)+" =");
        LOGGER.info("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
        LOGGER.info("=                       Authors                           =");
        Arrays.stream(StarLockManager.Authors).forEach(str -> {
            LOGGER.info("=   "+str);
        });
        LOGGER.info("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n");
    }
    private static Options getOptions() {
        final Options options = new Options();
        options.addOption(new Option("i","input", true, "Input file."));
        options.addOption(new Option("o","output", true, "Output file."));
        options.addOption(new Option( "l","libs", true, "Lib dir."));
        options.addOption(new Option( "cfg","config", true, "Config file."));
        return options;
    }
}
/*
try {
                zipFile.putNextEntry(new ZipEntry("Loader.class"));
                            /*if(wrapper.getName().equals(mainClass)){
                                zipFile.write(wrapper.write());
                            } else {
InputStream stream = Main.class.getResourceAsStream("/Loader.class");

    ClassNode classNode = new ClassNode(Opcodes.ASM9);
    ClassReader reader = new ClassReader(stream);
//System.out.println(classNode.name);
                reader.accept(classNode, Opcodes.ASM9);
                        classNode.name = getFixedNameLoader(classNode.name);
                        MethodNode clinit = classNode.methods.stream().filter(mh ->  mh.name.equals("<clinit>")).findFirst().orElse(null);
                        boolean created = false;
                        if(clinit == null){
                        created = true;
                        classNode.methods.add(new MethodNode(Opcodes.ACC_STATIC,"<clinit>", "()V", null, null));
                        clinit = classNode.methods.stream().filter(mh ->  mh.name.equals("<clinit>")).findFirst().orElse(null);
                        }
                        InsnList list = new InsnList();
                        ClassEncryptorTransformer.keysForDecrypt.forEach((pathToClass, key) -> {
                        list.add(new LabelNode());
                        list.add(new FieldInsnNode(Opcodes.GETSTATIC, getFixedNameLoader(classNode.name), "ugaBuga","Ljava/util/Map;"));
                        list.add(new LdcInsnNode(new String(Base64.getEncoder().encode(pathToClass.getBytes()))));
                        list.add(new LdcInsnNode(new String(Base64.getEncoder().encode(key))));
                        list.add(new MethodInsnNode(Opcodes.INVOKEINTERFACE, "java/util/Map", "put","(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"));
                        list.add(new InsnNode(Opcodes.POP));
                        });
                        list.add(new LdcInsnNode(new String(Base64.getEncoder().encode(getMainManifest().getBytes()))));
                        list.add(new FieldInsnNode(Opcodes.PUTSTATIC, getFixedNameLoader(classNode.name), "mainClass","Ljava/lang/String;"));
                        if(created){
                        list.add(new LabelNode());
                        list.add(new InsnNode(Opcodes.RETURN));
                        }
                        clinit.instructions.insertBefore(clinit.instructions.toArray()[clinit.instructions.toArray().length-1],list);

                        byte[] data = classToBytes(classNode);
                        zipFile.write(data);
                        zipFile.closeEntry();
                        } catch (Throwable throwable) {
                        // throwable.printStackTrace();
                        }
                        try {
                        zipFile.putNextEntry(new ZipEntry("Loader$1.class"));
                        InputStream stream = Main.class.getResourceAsStream("/Loader$1.class");

        ClassNode classNode = new ClassNode(Opcodes.ASM9);
        ClassReader reader = new ClassReader(stream);
        reader.accept(classNode, Opcodes.ASM9);

        byte[] data = classToBytes(classNode);
        zipFile.write(data);
        zipFile.closeEntry();
        } catch (Throwable throwable) {
        // throwable.printStackTrace();
        }
*/
