package starlock.obfuscator;

import starlock.obfuscator.transformers.*;
import starlock.utils.ASMHelper;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import starlock.utils.wrapper.ClassWrapper;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.util.*;

public class Obfuscator extends ASMHelper {
    public void run() {
        List<Transformer> transformers = new ArrayList<>();
        transformers.add(new StringTransformer());
        transformers.add(new NumberTransformer());

        //TODO: НЕ ТРОГАТЬ СУКА
        //transformers.add(new InvokeDynamicTransformer()); //TODO: ЭТО БЛЯТЬ INVOKEDYNAMIC
        //TODO: НЕ ТРОГАТЬ СУКА

        transformers.add(new ControlFlowTransformer());
        transformers.add(new RenamerTransformer());
        transformers.add(new AccessTransformer());
        transformers.add(new WaterMarkTransformer());
        transformers.add(new MiscellaneousTransformer());

        transformers.forEach(transformer -> {
            LOGGER.info("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
            LOGGER.info("      {} running...", transformer.name());
            transformer.transform(this);
            LOGGER.info("      {} finished!", transformer.name());
            LOGGER.info("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n");
        });
    }

    public List<ClassNode> getClasses(){
        List<ClassNode> toReturn = new ArrayList<>();
        CLASSES.forEach((a, c) -> toReturn.add(c.getClassNode()));
        return toReturn;
    }
    public byte[] getFile(String forGet){
        final byte[][] toReturn = {null};
        FILES.forEach((name, data) -> {
            if(name.equals(forGet)){
                toReturn[0] = data;
            }
        });
        return toReturn[0];
    }
    public void setFile(String name, byte[] data){
        FILES.put(name, data);
    }
    public void setClass(String name, byte[] data){
        CLASSES.put(name, new ClassWrapper(data));
    }

    private static void processHideCode(ClassNode classNode) {
        classNode.access &= ~(Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
        classNode.access |= (Opcodes.ACC_SYNTHETIC | Opcodes.ACC_PUBLIC);

        classNode.methods.forEach(method -> {
            if (!method.name.equals("<init>") && !method.name.equals("<clinit>")) {
                method.access &= ~(Opcodes.ACC_VARARGS | Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
                method.access |= (Opcodes.ACC_PUBLIC | Opcodes.ACC_SYNTHETIC | Opcodes.ACC_BRIDGE);
            } else {
                method.access &= ~(Opcodes.ACC_VARARGS | Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
                method.access |= (Opcodes.ACC_PUBLIC | Opcodes.ACC_SYNTHETIC);
            }

            //if ((Opcodes.ACC_STATIC & method.access) != 0)
            //    method.access |= (Opcodes.ACC_SYNTHETIC | Opcodes.ACC_BRIDGE);

            if (method.parameters != null)
                for (ParameterNode pn : method.parameters)
                    pn.access |= (Opcodes.ACC_SYNTHETIC);
        });

        classNode.fields.forEach(field -> {
            field.access &= ~(Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
            field.access |= (Opcodes.ACC_SYNTHETIC | Opcodes.ACC_PUBLIC);
        });
    }

    private static byte[] encrypt(byte[] bytes, String klass, String method, String hash, int keyLength) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(hash);
            SecretKeySpec secretKey = new SecretKeySpec(Arrays.copyOf(messageDigest.digest((klass + method).getBytes()), keyLength), "AES");
            Cipher encoder = Cipher.getInstance("AES/ECB/PKCS5Padding");
            encoder.init(Cipher.ENCRYPT_MODE, secretKey);
            return Base64.getEncoder().encode(encoder.doFinal(bytes));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}