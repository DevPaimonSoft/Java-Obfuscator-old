package starlock.obfuscator.transformers;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.ref.HeavyInvokeDynamic;
import starlock.obfuscator.transformers.impl.watermark.ConsoleTransformer;
import starlock.obfuscator.transformers.impl.watermark.MetaInfTransformer;
import starlock.obfuscator.transformers.impl.watermark.WClassTransformer;

public class WaterMarkTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        if(getConfig().getBoolean("Watermark.META-INF")){
            new MetaInfTransformer().obfuscate(obfuscator);
        }
        //if(getConfig().getBoolean("Watermark.META-INF")){
        //    new MetaInfTransformer().obfuscate(obfuscator);
        //}
        new ConsoleTransformer().obfuscate(obfuscator);
        //new WClassTransformer().obfuscate(obfuscator);
    }
}
