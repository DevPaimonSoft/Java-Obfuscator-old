package starlock.obfuscator.transformers;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;

public class NativeTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        //
    }
}
