package starlock.obfuscator.transformers;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.access.ClassAccessTransformer;
import starlock.obfuscator.transformers.impl.access.FieldAccessTransformer;
import starlock.obfuscator.transformers.impl.access.MethodAccessTransformer;
import starlock.obfuscator.transformers.impl.renamer.LocalVaribleTransformer;

public class AccessTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        new MethodAccessTransformer().obfuscate(obfuscator);
        new FieldAccessTransformer().obfuscate(obfuscator);
        new ClassAccessTransformer().obfuscate(obfuscator);
    }
}