package starlock.obfuscator.transformers.impl.access;

import org.objectweb.asm.Opcodes;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.AccessTransformer;

public class ClassAccessTransformer extends AccessTransformer {
    public void obfuscate(Obfuscator obfuscator){
        obfuscator.getClasses().forEach(classNode -> {
            classNode.methods.forEach(methodNode -> {
                classNode.access &= ~(Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
                classNode.access |= (Opcodes.ACC_SYNTHETIC | Opcodes.ACC_PUBLIC);
            });
        });
    }
}