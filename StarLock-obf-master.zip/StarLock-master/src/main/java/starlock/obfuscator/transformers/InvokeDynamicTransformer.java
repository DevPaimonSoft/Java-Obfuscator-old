package starlock.obfuscator.transformers;

import org.objectweb.asm.Handle;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.ref.HeavyInvokeDynamic;

import java.util.Arrays;

public class InvokeDynamicTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        switch (getConfig().getString("InvokeDynamic.Mode")){
            case "Light" -> new HeavyInvokeDynamic().obfuscate(obfuscator);
            case "Medium" -> new HeavyInvokeDynamic().obfuscate(obfuscator);
            case "Heavy" -> new HeavyInvokeDynamic().obfuscate(obfuscator);
            default -> throw new IllegalArgumentException();
        }
    }
}
