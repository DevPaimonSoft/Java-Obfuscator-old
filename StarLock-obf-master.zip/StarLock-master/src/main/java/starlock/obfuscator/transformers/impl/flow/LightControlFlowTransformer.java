package starlock.obfuscator.transformers.impl.flow;

import lombok.val;
import org.objectweb.asm.tree.*;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.ControlFlowTransformer;

import java.util.Arrays;
import java.util.Random;

public class LightControlFlowTransformer extends ControlFlowTransformer {
    //private final FieldNode negativeField = new FieldNode(ACC_PRIVATE + ACC_STATIC + ACC_SYNTHETIC, getRandomInvalidString(50,1), "I", null, new Random().nextInt(347856));
    //private final FieldNode positiveField = new FieldNode(ACC_PRIVATE + ACC_STATIC + ACC_SYNTHETIC, getRandomInvalidString(50,1), "I", null, new Random().nextInt(347857,87873484));
    //private final FieldNode negativeField = new FieldNode(ACC_PRIVATE + ACC_STATIC + ACC_SYNTHETIC, "negativeField", "I", null, new Random().nextInt(347856));
    //private final FieldNode positiveField = new FieldNode(ACC_PRIVATE + ACC_STATIC + ACC_SYNTHETIC, "positiveField", "I", null, new Random().nextInt(347857,87873484));

    public void obfuscate(Obfuscator obfuscator) {
        obfuscator.getClasses().forEach(classNode -> {
            //final int[] i = {1};
            //final int[] jump = {1};
            //classNode.fields.add(negativeField);
            //classNode.fields.add(positiveField);
            //final long[] key = {new Random().nextLong()};
            //FieldNode field = new FieldNode(ACC_PRIVATE+ACC_STATIC+ACC_SYNTHETIC,getRandomInvalidString(39,2),"J",null, key[0]);
            //classNode.fields.add(field);
            classNode.methods.stream()
                    .filter(methodNode -> !methodNode.name.equals("<init>"))
                    .filter(methodNode -> !methodNode.name.equals("<clinit>"))
                    .forEach(methodNode -> {
                //var methodAllVars = methodNode.localVariables.size();

                //final long[] decKey = {new Random().nextLong()};
                //final int[] varInt = {methodAllVars+2};
                //final int[] StringVar = {varInt[0]+1};

                //final boolean[] returned = {false};
                //methodNode.instructions.insertBefore(methodNode.instructions.getFirst(), getStartKey(key[0], varInt[0]));
                Arrays.stream(methodNode.instructions.toArray())
                        .forEach(insn -> {
                            if(isInteger(insn)){
                                val list = new InsnList();
                                val intDec = new Random().nextInt();
                                val intDec2 = new Random().nextInt();
                                val origInt = getInteger(insn);
                                val forPaste = (origInt ^ intDec ^ intDec2);

                                list.add(new LdcInsnNode(Integer.toString(intDec)));
                                list.add(new MethodInsnNode(INVOKESTATIC,"java/lang/Integer","parseInt","(Ljava/lang/String;)I"));
                                list.add(new InsnNode(IXOR));
                                list.add(new LdcInsnNode(intDec2));
                                list.add(new InsnNode(IXOR));

                                methodNode.instructions.insert(insn, list);
                                methodNode.instructions.set(insn, new LdcInsnNode(forPaste));
                            } else if(insn.getOpcode() >= IFEQ && insn.getOpcode() <= IF_ACMPNE){
                                val jumpInsnNode = ((JumpInsnNode)insn);
                                val offset = new LabelNode();
                                val insnList = new InsnList();

                                insnList.add(new JumpInsnNode(GOTO, jumpInsnNode.label));
                                insnList.add(offset);

                                jumpInsnNode.setOpcode(reverseJump(insn.getOpcode()));
                                jumpInsnNode.label = offset;

                                methodNode.instructions.insert(jumpInsnNode, insnList);
                            }
                            //if (insn instanceof LabelNode && i[0] % 12 == 0
                            //        && new Random().nextBoolean() && methodNode.instructions.indexOf(insn) > 5) {
                            //    methodNode.instructions.insert(insn, this.getSwitchBlockInt(key[0], decKey[0], field, classNode.name));
                            //    key[0] ^= decKey[0];
                            //    decKey[0] = new Random().nextLong();
                            //    //++varInt[0];
                            //    //++StringVar[0];
                            //}
                            //else if(isInteger(insn) && new Random().nextBoolean() && methodNode.instructions.indexOf(insn) > 5){
                            //    int orig = getInteger(insn);
                            //    int key1 = key[0];
                            //    int encrypt = (orig ^ key1);
                            //    final InsnList insnList = new InsnList();
                            //    insnList.add(new VarInsnNode(ILOAD, varInt[0]));
                            //    insnList.add(new InsnNode(IXOR));
                            //    methodNode.instructions.insert(insn,insnList);
                            //    methodNode.instructions.set(insn, new LdcInsnNode(encrypt));
                            //}
                            //++i[0];
                        });
            });
        });
    }
    private InsnList getStartKey(final int key, final int varInt) {
        final InsnList insnList = new InsnList();

        insnList.add(new LdcInsnNode(key));
        insnList.add(new VarInsnNode(ISTORE, varInt));

        return insnList;
    }
    private InsnList getStartString(final String key, final int varInt) {
        final InsnList insnList = new InsnList();

        insnList.add(new LdcInsnNode(key));
        insnList.add(new VarInsnNode(ASTORE, varInt));

        return insnList;
    }
    private int reverseJump(int opcode){
        return switch (opcode){
            case IFNE -> IFEQ;
            case IFEQ -> IFNE;
            case IFGE -> IFLT;
            case IFGT -> IFLE;
            case IFLE -> IFGT;
            case IFLT -> IFGE;
            case IFNONNULL -> IFNULL;
            case IFNULL -> IFNONNULL;
            case IF_ACMPEQ -> IF_ACMPNE;
            case IF_ACMPNE -> IF_ACMPEQ;
            case IF_ICMPEQ -> IF_ICMPNE;
            case IF_ICMPNE -> IF_ICMPEQ;
            case IF_ICMPGE -> IF_ICMPLT;
            case IF_ICMPGT -> IF_ICMPLE;
            case IF_ICMPLE -> IF_ICMPGT;
            case IF_ICMPLT -> IF_ICMPGE;
            default -> throw new IllegalStateException(String.format("Unable to reverse jump opcode: %d", opcode));
        };
    }
    private InsnList getSwitchBlockInt(final long key, final long decKey, final FieldNode field, String owner) {
        final InsnList insnList = new InsnList();
        final LabelNode L0 = new LabelNode(),L1 = new LabelNode(),L2 = new LabelNode(),L3 = new LabelNode(),L4 = new LabelNode();
        LabelNode[] labels = {L0,L1,L2};
        int[] keys = {new Random().nextInt(), new Random().nextInt(), (int)key};
        final LabelNode defLabel = new LabelNode();



        insnList.add(L4);
        insnList.add(new FieldInsnNode(GETSTATIC,owner, field.name, field.desc));
        insnList.add(new LookupSwitchInsnNode(L3, keys, labels));

        insnList.add(L0);
        insnList.add(new FieldInsnNode(GETSTATIC,owner, field.name, field.desc));;
        insnList.add(new LdcInsnNode(new Random().nextLong()));
        insnList.add(new InsnNode(LXOR));
        insnList.add(new FieldInsnNode(PUTSTATIC,owner, field.name, field.desc));
        insnList.add(new JumpInsnNode(GOTO, defLabel));

        insnList.add(L1);
        insnList.add(new FieldInsnNode(GETSTATIC,owner, field.name, field.desc));
        insnList.add(new LdcInsnNode(new Random().nextLong()));
        insnList.add(new InsnNode(LXOR));
        insnList.add(new FieldInsnNode(PUTSTATIC,owner, field.name, field.desc));
        insnList.add(new JumpInsnNode(GOTO, defLabel));

        insnList.add(L2);
        insnList.add(new FieldInsnNode(GETSTATIC,owner, field.name, field.desc));
        insnList.add(new LdcInsnNode(decKey));
        insnList.add(new InsnNode(LXOR));
        insnList.add(new FieldInsnNode(PUTSTATIC,owner, field.name, field.desc));
        insnList.add(new JumpInsnNode(GOTO, defLabel));

        insnList.add(L3);
        insnList.add(new LdcInsnNode(new Random().nextLong()));
        insnList.add(new LdcInsnNode(new Random().nextLong()));
        insnList.add(new InsnNode(LXOR));
        insnList.add(new FieldInsnNode(PUTSTATIC,owner, field.name, field.desc));
        insnList.add(new JumpInsnNode(GOTO, defLabel));

        insnList.add(defLabel);
        return insnList;
    }
    private InsnList getSwitchBlockString(final int key, final int varS, final String originalLDC) {
        final InsnList insnList = new InsnList();
        final LabelNode L0 = new LabelNode(),L1 = new LabelNode(),L2 = new LabelNode(),L3 = new LabelNode();
        LabelNode[] labels = {L0,L1,L2};
        int[] keys = {new Random().nextInt(), new Random().nextInt(), key};
        final LabelNode defLabel = new LabelNode();



        //insnList.add(new LdcInsnNode(getRandomInvalidString(originalLDC.length(), 1)));
        //insnList.add(new VarInsnNode(ALOAD, varS));
        insnList.add(new LookupSwitchInsnNode(L3, keys, labels));

        insnList.add(L0);
        insnList.add(new LdcInsnNode(getRandomInvalidString(originalLDC.length(), 1)));
        insnList.add(new VarInsnNode(ASTORE, varS));
        insnList.add(new JumpInsnNode(GOTO, defLabel));

        insnList.add(L1);
        insnList.add(new LdcInsnNode(getRandomInvalidString(originalLDC.length(), 1)));
        insnList.add(new VarInsnNode(ASTORE, varS));
        insnList.add(new JumpInsnNode(GOTO, defLabel));

        insnList.add(L2);
        insnList.add(new LdcInsnNode(originalLDC));
        insnList.add(new VarInsnNode(ASTORE, varS));
        insnList.add(new JumpInsnNode(GOTO, defLabel));

        insnList.add(L3);
        insnList.add(new LdcInsnNode(getRandomInvalidString(originalLDC.length(), 1)));
        insnList.add(new VarInsnNode(ASTORE, varS));
        insnList.add(new JumpInsnNode(GOTO, defLabel));

        insnList.add(defLabel);
        return insnList;
    }
}
