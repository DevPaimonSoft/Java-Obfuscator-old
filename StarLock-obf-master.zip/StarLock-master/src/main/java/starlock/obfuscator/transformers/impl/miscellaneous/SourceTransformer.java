package starlock.obfuscator.transformers.impl.miscellaneous;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.MiscellaneousTransformer;

import java.util.Random;

public class SourceTransformer extends MiscellaneousTransformer {
    public void obfuscate(Obfuscator obfuscator){
        if(getConfig().getBoolean("Miscellaneous.Source.Remove")){
            obfuscator.getClasses().forEach(classNode -> {
                classNode.sourceDebug = null;
                classNode.sourceFile = null;
            });
        } else {
            obfuscator.getClasses().forEach(classNode -> {
                classNode.sourceDebug = getRandomInvalidString(new Random().nextInt(256),new Random().nextInt(3));
                classNode.sourceFile = getRandomInvalidString(new Random().nextInt(256),new Random().nextInt(3));
            });
        }
    }
}
