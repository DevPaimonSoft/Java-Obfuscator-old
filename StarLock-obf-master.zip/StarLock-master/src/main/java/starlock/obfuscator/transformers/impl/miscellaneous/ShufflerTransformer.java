package starlock.obfuscator.transformers.impl.miscellaneous;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.MiscellaneousTransformer;

import java.util.Collections;

public class ShufflerTransformer extends MiscellaneousTransformer {
    public void obfuscate(Obfuscator obfuscator){
        obfuscator.getClasses().forEach(classNode -> {
            Collections.shuffle(classNode.methods);
            Collections.shuffle(classNode.fields);
        });
    }
}