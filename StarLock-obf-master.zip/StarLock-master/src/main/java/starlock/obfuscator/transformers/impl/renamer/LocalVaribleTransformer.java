package starlock.obfuscator.transformers.impl.renamer;

import org.objectweb.asm.tree.LocalVariableNode;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.RenamerTransformer;
import starlock.obfuscator.transformers.impl.miscellaneous.TrashClassesTransformer;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LocalVaribleTransformer extends RenamerTransformer {

    public void obfuscate(Obfuscator obfuscator){
        if(getConfig().getBoolean("Renamer.LocalVariables.Remove")){
            obfuscator.getClasses().forEach(classNode ->
                        classNode.methods.forEach(methodNode -> methodNode.localVariables = null));
        } else {
            obfuscator.getClasses().forEach(classNode -> {
                        classNode.methods.forEach(methodNode -> {
                            if(methodNode.localVariables != null){
                                methodNode.localVariables.forEach(var
                                        -> var.name = getRandomInvalidString(new Random().nextInt(50,300),new Random().nextInt(1,3)));
                            }
                        });
                    });
        }
    }
}
