package starlock.obfuscator.transformers.impl.renamer;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.RenamerTransformer;
import starlock.utils.CustomRemapper;
import starlock.utils.SkidRemapper;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class ClassTransformer extends RenamerTransformer {

    public void obfuscate(Obfuscator obfuscator){
        List<String> names = getConfig().getStringList("Renamer.Path");
        AtomicInteger ipp = new AtomicInteger();
        obfuscator.getClasses()
                //.stream()
                //.filter(classNode -> names.contains(classNode.name.replaceAll("/",".")))
                .forEach(classNode -> {
                    String newName = getRandomInvalidString(new Random().nextInt(30,100),new Random().nextInt(1,3));
                    String newPackage = getConfig().getString("Renamer.Repackage");
                    StringBuilder oldName = new StringBuilder();
                    int count = (classNode.name.split("/").length-1);
                    for(int i = 0; i < count; ++i){
                        oldName.append(classNode.name.split("/")[i]);
                    }

                    //remapper.mapPackage(oldName.toString(), newPackage);
                    //remapper.mapMethodName(classNode.name.split("/")[count], newName);
                    ipp.getAndIncrement();
                    //classNode.methods.stream()
                    //        .filter(methodNode -> !methodNode.name.equals("<init>"))
                    //        .filter(methodNode -> !methodNode.name.equals("<clinit>"))
                    //        .filter(methodNode -> !methodNode.name.equals("main"))
                    //        .forEach(methodNode -> {
                    //            String newName = getRandomInvalidString(new Random().nextInt(30,100),new Random().nextInt(1,3));
                    //            //methodNode.name = newName;
                    //            if(remapper.mapMethodName(classNode.name, methodNode.name, methodNode.desc, newName, true)){
                    //                ipp.getAndIncrement();
                    //            }
                    //});
                });
        LOGGER.info("Info->");
        LOGGER.info("  - Renamed: "+ipp.get());
    }
}
