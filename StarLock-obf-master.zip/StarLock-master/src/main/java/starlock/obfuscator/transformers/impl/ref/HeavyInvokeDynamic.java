package starlock.obfuscator.transformers.impl.ref;

import jdk.dynalink.linker.support.Lookup;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.InvokeDynamicTransformer;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;

public class HeavyInvokeDynamic extends InvokeDynamicTransformer {
    public static String spliter = randomString(5);
    public void obfuscate(Obfuscator obfuscator) {
        obfuscator.getClasses().forEach(classNode -> {
            classNode.methods.forEach(methodNode -> {
                Arrays.stream(methodNode.instructions.toArray())
                        .forEach(insn -> {
                            if(insn instanceof MethodInsnNode && insn.getOpcode() == INVOKESTATIC){
                                String key = new String(Base64.getEncoder().encode(randomString(16).getBytes(StandardCharsets.UTF_8)));
                                String arg = ((MethodInsnNode) insn).owner+spliter+((MethodInsnNode) insn).name+spliter+((MethodInsnNode) insn).desc+spliter+((MethodInsnNode) insn).owner+spliter+11111;
                                String banan = encryptString(key,arg);

                                var handle = new Handle(H_INVOKESTATIC, "StarLock", "decrypt", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", false);

                                var desc = ((MethodInsnNode)insn).desc;

                                if (insn.getOpcode() == INVOKESTATIC)
                                    desc = "(Ljava/lang/Object;" + desc.substring(1);

                                var invokeDynamic = new InvokeDynamicInsnNode(key, getGenericMethodDescriptor(desc), handle, banan);

                                methodNode.instructions.set(insn, invokeDynamic);



                                //String banan = ((MethodInsnNode) insn).owner+spliter+((MethodInsnNode) insn).name+spliter+((MethodInsnNode) insn).desc+spliter+((MethodInsnNode) insn).owner+spliter+11111;
                                //String key = getRandomInvalidString(banan.length(), 1);
                                //Handle handle = new Handle(H_INVOKESTATIC, "StarLock", "decrypt", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", false);
                                //ArrayList<Object> arguments = new ArrayList<>();
                                //arguments.add(Lookup.PUBLIC); // первый объект
                                //arguments.add(encryptString(banan, key)); // второй объект
                                //arguments.add(Type.getMethodType(((MethodInsnNode) insn).desc)); // третий объект
                                //arguments.add(key); // четвертый объект
                                //methodNode.instructions.set(insn, new InvokeDynamicInsnNode("dec474rypt", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",handle, arguments.toArray()));
                            }
                        });
            });
        });
    }
    public String getGenericMethodDescriptor(String desc) {
        var returnType = Type.getReturnType(desc);
        var args = Type.getArgumentTypes(desc);

        for (int i = 0; i < args.length; i++) {
            var arg = args[i];

            if (arg.getSort() == Type.OBJECT)
                args[i] = Type.getType("Ljava/lang/Object;");
        }
        return Type.getMethodDescriptor(returnType, args);
    }
    public static String encryptString(String var0, String var1) {
        char[] var5 = (new String(Base64.getEncoder().encode((var0).getBytes(StandardCharsets.UTF_8)))).toCharArray();
        char[] var6 = new char[var1.toCharArray().length];
        char[] var7 = var1.toCharArray();

        for(int var8 = 0; var8 < var7.length; ++var8) {
            var6[var8] = (char)(var7[var8] ^ var5[var8 % 16]);
        }

        byte[] var22 = (new String(var6)).getBytes();
        return new String(var22);
    }
}
