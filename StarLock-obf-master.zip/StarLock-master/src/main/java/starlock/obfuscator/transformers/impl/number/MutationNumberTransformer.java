package starlock.obfuscator.transformers.impl.number;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.*;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.NumberTransformer;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class MutationNumberTransformer extends NumberTransformer {
    public static int key = (new Random()).nextInt();
    public void obfuscate(Obfuscator obfuscator) {
        obfuscator.getClasses().forEach(classNode -> {
            classNode.methods.forEach(methodNode -> {
                Arrays.stream(methodNode.instructions.toArray())
                        .forEach(insn -> {
                            if(isInteger(insn)){
                                String encrypted = encrypt(getInteger(insn), key);

                                InsnList list = new InsnList();
                                list.add(new LdcInsnNode(encrypted));
                                list.add(new LdcInsnNode(0));
                                list.add(new LdcInsnNode((new Random()).nextInt()));
                                list.add(new MethodInsnNode(INVOKESTATIC, "StarLock", "decrypt", "(Ljava/lang/String;II)Ljava/lang/String;"));
                                list.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Integer", "parseInt", "(Ljava/lang/String;)I"));

                                methodNode.instructions.insertBefore(insn, list);
                                methodNode.instructions.remove(insn);

                            } else if(isLong(insn)){
                                String encrypted = encrypt(getLong(insn), key);

                                InsnList list = new InsnList();
                                list.add(new LdcInsnNode(encrypted));
                                list.add(new LdcInsnNode(0));
                                list.add(new LdcInsnNode((new Random()).nextInt()));
                                list.add(new MethodInsnNode(INVOKESTATIC, "StarLock", "decrypt", "(Ljava/lang/String;II)Ljava/lang/String;"));
                                list.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Long", "parseLong", "(Ljava/lang/String;)J"));

                                methodNode.instructions.insertBefore(insn, list);
                                methodNode.instructions.remove(insn);

                            }
                        });
            });


            /*InputStream stream = MutationNumberTransformer.class.getResourceAsStream("/libs/StarLock.class");
            ClassNode classNode2 = new ClassNode(Opcodes.ASM9);
            ClassReader reader;
            try {
                reader = new ClassReader(stream);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            reader.accept(classNode2, Opcodes.ASM9);
            classNode2.methods.forEach(methodNode -> {
                if(methodNode.name.equals("decrypt")){
                    Arrays.stream(methodNode.instructions.toArray())
                            .forEach(insn -> {
                                if(isInteger(insn) && getInteger(insn) == 1122331334){
                                    methodNode.instructions.set(insn, new LdcInsnNode(key));
                                }
                            });
                    if(methodNode.invisibleAnnotations == null){
                        methodNode.invisibleAnnotations = new ArrayList<>();
                    }
                    methodNode.localVariables = null;
                    methodNode.invisibleAnnotations.add(new AnnotationNode("StarLock(NativeTransformer)"));
                    classNode.methods.add(methodNode);
                }
            });*/
        });
    }
    private String encrypt(long toObf, int key){
        char[] str = Long.toString(toObf).toCharArray();
        StringBuilder encrypted = new StringBuilder();
        for (char c : str) {
            encrypted.append((char) ((int) c ^ key));
        }
        return encrypted.toString();
    }
}
