package starlock.obfuscator.transformers;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.renamer.ClassTransformer;
import starlock.obfuscator.transformers.impl.renamer.LocalVaribleTransformer;

public class RenamerTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        new LocalVaribleTransformer().obfuscate(obfuscator);
        //new ClassTransformer().obfuscate(obfuscator);
    }
}