package starlock.obfuscator.transformers.impl.natives;

public class NativeStringTransformer {
}
