package starlock.obfuscator.transformers;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.miscellaneous.*;

public class MiscellaneousTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        if(getConfig().getInt("Miscellaneous.TrashClasses") != 0){
            new TrashClassesTransformer().obfuscate(obfuscator);
        }
        if(getConfig().getBoolean("Miscellaneous.Source.Enabled")){
            new SourceTransformer().obfuscate(obfuscator);
        }
        if(getConfig().getBoolean("Miscellaneous.Shuffler")){
            new ShufflerTransformer().obfuscate(obfuscator);
        }
    }
}
