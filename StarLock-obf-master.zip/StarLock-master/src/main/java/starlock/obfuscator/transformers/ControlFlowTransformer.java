package starlock.obfuscator.transformers;

import org.objectweb.asm.tree.*;
import starlock.Main;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.flow.LightControlFlowTransformer;
import starlock.obfuscator.transformers.impl.flow.NormalControlFlowTransformer;
import starlock.obfuscator.transformers.impl.ref.HeavyInvokeDynamic;
import starlock.utils.StringUtil;
import starlock.utils.wrapper.ClassWrapper;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class ControlFlowTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        switch (getConfig().getString("FlowObfuscation.Mode")){
            case "Light" -> new LightControlFlowTransformer().obfuscate(obfuscator);
            case "Normal" -> new NormalControlFlowTransformer().obfuscate(obfuscator);
            case "Heavy" -> new LightControlFlowTransformer().obfuscate(obfuscator);
            default -> throw new IllegalArgumentException();
        }
    }
}
