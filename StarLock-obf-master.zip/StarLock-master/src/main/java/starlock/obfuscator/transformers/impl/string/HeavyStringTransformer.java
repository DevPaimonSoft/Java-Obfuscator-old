package starlock.obfuscator.transformers.impl.string;

import org.objectweb.asm.tree.*;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.StringTransformer;

import java.util.Arrays;
import java.util.Random;

public class HeavyStringTransformer extends StringTransformer {
    public static int key2 = (new Random()).nextInt();
    public void obfuscate(Obfuscator obfuscator){
        obfuscator.getClasses().forEach(classNode -> {
            classNode.methods.forEach(methodNode -> {
                Arrays.stream(methodNode.instructions.toArray())
                        .forEach(insn -> {
                            if (isString(insn)){
                                //System.err.println(methodNode.name);
                                int key = (new Random()).nextInt();
                                String encrypted = encrypt(getString(insn), key, key2);
                                //LOGGER.atError().log("Encrypted ->" + encrypted);
                                //LOGGER.atError().log("Key ->" + key);
                                //LOGGER.atError().log("Decrypted ->" + encrypt(encrypted, key, key2));

                                InsnList list = new InsnList();
                                list.add(new LdcInsnNode(encrypted));
                                list.add(new LdcInsnNode(1));
                                list.add(new LdcInsnNode(key));
                                list.add(new MethodInsnNode(INVOKESTATIC, "StarLock", "decrypt", "(Ljava/lang/String;II)Ljava/lang/String;"));

                                //LOGGER.atError().log(getInteger(insn) + " -> " + encrypted);

                                methodNode.instructions.insertBefore(insn, list);
                                methodNode.instructions.remove(insn);
                            } else if(insn instanceof InvokeDynamicInsnNode invoke && invoke.name.equals("makeConcatWithConstants")){
                                //System.err.println(invoke.bsmArgs[0]);
                            }
                        });
            });
        });
    }
    public String encrypt(String var0, int var3, int key) {
        char[] var1 = var0.toCharArray();
        char[] banan = var0.toCharArray();
        for(int var11 = 0; var11 < var1.length; ++var11) {
            var1[var11] = (char)(banan[var11] ^ var3);
        }
        char[] var17 = new char[var1.length];
        for(int var18 = 0; var18 < var17.length; ++var18) {
            switch (var18 % 3) {
                case 0 -> var17[var18] = (char) (var3 ^ key ^ var1[var18]);
                case 1 -> var17[var18] = (char) (key ^ var1[var18]);
                case 2 -> var17[var18] = (char) (var1[var18] ^ key);
            }
        }

        return new String(var17);
    }
}
