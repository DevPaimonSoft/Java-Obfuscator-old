package starlock.obfuscator.transformers;

import org.objectweb.asm.tree.ClassNode;
import starlock.Main;
import starlock.obfuscator.Obfuscator;

import java.util.Arrays;
import java.util.Base64;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

public class ClassEncryptorTransformer extends Obfuscator {
    public static final Map<String, byte[]> keysForDecrypt = new ConcurrentHashMap<>();
    public byte[] obfuscate(byte[] bytes, String name){
        //System.out.println(name);
        byte[] keys = new byte[7];
        for(int i = 0; i < 7; ++i){
            byte lenght = (byte)(new Random()).nextInt(128);
            keys[i] = lenght;
        }
        keysForDecrypt.put(name,keys);
        //System.out.println(Arrays.toString(keys));
        //String encoded = new String(Base64.getEncoder().encode(keys));
        //System.out.println(encoded);
        //System.out.println(Arrays.toString(Base64.getDecoder().decode(encoded.getBytes())));
        //System.out.println(Arrays.toString(bytes));
        //System.out.println(bytes.length);
        for (int i = 0; i< bytes.length; ++i){
            if(i>=4){
                switch (i-4) {
                    case 0 -> bytes[i] ^= keys[0];
                    case 1 -> bytes[i] ^= keys[1];
                    case 2 -> bytes[i] ^= keys[2];
                    case 3 -> bytes[i] ^= keys[3];
                    case 4 -> bytes[i] ^= keys[4];
                    case 5 -> bytes[i] ^= keys[5];
                    default -> bytes[i] ^= keys[6];
                }
            }
        }
        System.out.println(keys[0]);
        System.out.println(keys[1]);
        System.out.println(keys[2]);
        System.out.println(keys[3]);
        System.out.println(keys[4]);
        System.out.println(keys[5]);
        System.out.println(keys[6]);
        //System.out.println(Arrays.toString(bytes));
        //System.out.println(bytes.length);
        return bytes;
    }
}
