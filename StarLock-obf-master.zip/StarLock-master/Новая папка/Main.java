// Type your code here, or load an example.
import java.util.Arrays;
class Main {
    public static void main(String[] args){
        System.out.println(Arrays.toString(args));
    }
}