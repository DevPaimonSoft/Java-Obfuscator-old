package starlock;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.*;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.ClassEncryptorTransformer;
import starlock.obfuscator.transformers.impl.number.MutationNumberTransformer;
import starlock.obfuscator.transformers.impl.ref.HeavyInvokeDynamic;
import starlock.obfuscator.transformers.impl.string.HeavyStringTransformer;
import starlock.utils.ASMHelper;
import starlock.utils.Utils;
import starlock.utils.wrapper.ClassWrapper;
import lombok.NonNull;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class Main extends Utils {
    public static final Random RANDOM = new Random();
    public static final List<ClassWrapper> CLASSES = new ArrayList<>();
    public static final Map<String, byte[]> ClassesBytes = new ConcurrentHashMap<>();
    public static final Map<String, byte[]> FILES = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        if(args.length == 1){
            if(!new File("config.yml").exists()){
                saveCFG();
            }
            File inputFile = new File(args[0]);
            try {
                ZipFile zipFile = new ZipFile(inputFile);
                zipFile.entries().asIterator().forEachRemaining(zipEntry -> {
                            try {
                                var is = zipFile.getInputStream(zipEntry);
                                var name = zipEntry.getName();
                                var buffer = is.readAllBytes();
                                if (isClassFile(name, buffer)) {
                                    CLASSES.add(new ClassWrapper(buffer));
                                } else  {
                                    FILES.put(name, buffer);
                                }

                                if(name.endsWith(".class")){
                                    ClassesBytes.put(name, buffer);
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                );
                new Obfuscator().run();
                saveOutput(inputFile.toPath());
            } catch (Exception ex){
                ex.printStackTrace();
            }
        } else {
            System.out.println("No arg!");
        }
    }
    private static void saveOutput(@NonNull Path path) {
        String outName = path.getFileName().toString().replace(".jar", "-obf.jar");
        try (ZipOutputStream zipFile = new ZipOutputStream(new FileOutputStream(outName))) {
            System.gc();
            CLASSES.forEach((wrapper) -> {
                try {
                    zipFile.putNextEntry(new ZipEntry(wrapper.getName() + ".class"));
                    /*if(wrapper.getName().equals(mainClass)){
                        zipFile.write(wrapper.write());
                    } else {*/
                    //String name = wrapper.getName();
                    byte[] toObf = classToBytes(wrapper.getClassNode());
                    //byte[] data = encrypt(toObf);
                    //byte[] data = new ClassEncryptorTransformer().obfuscate(toObf,name);
                    zipFile.write(toObf);
                    /* }*/
                    zipFile.closeEntry();
                } catch (Throwable throwable) {
                    // throwable.printStackTrace();
                }
            });
            FILES.forEach((name, buffer) -> {
                if (name.endsWith("/"))
                    return;
                try {
                    zipFile.putNextEntry(new ZipEntry(name));
                    zipFile.write(buffer);
                    zipFile.closeEntry();
                } catch (Throwable throwable) {
                    //throwable.printStackTrace();
                }
            });

            //TODO: save lib and replace values
            InputStream stream = Main.class.getResourceAsStream("/StarLock.class");
            ClassNode classNode = new ClassNode(Opcodes.ASM9);
            ClassReader reader = new ClassReader(stream);;
            reader.accept(classNode, Opcodes.ASM9);

            classNode.methods.forEach(methodNode -> {
                Arrays.stream(methodNode.instructions.toArray())
                        .forEach(insn -> {
                            if(ASMHelper.isInteger(insn) && ASMHelper.getInteger(insn) == 1122331334){
                                methodNode.instructions.set(insn, new LdcInsnNode(MutationNumberTransformer.key));
                            } else if(ASMHelper.isInteger(insn) && ASMHelper.getInteger(insn) == 345345777){
                                methodNode.instructions.set(insn, new LdcInsnNode(HeavyStringTransformer.key2));
                            } else if(ASMHelper.isString(insn) && ASMHelper.getString(insn).equals("SPLITSTRING")){
                                methodNode.instructions.set(insn, new LdcInsnNode(HeavyInvokeDynamic.spliter));
                            }
                        });
                if(methodNode.invisibleAnnotations == null){
                    methodNode.invisibleAnnotations = new ArrayList<>();
                }
                methodNode.localVariables = null;
                methodNode.invisibleAnnotations.add(new AnnotationNode("StarLock(NativeTransformer)"));
            });

            zipFile.putNextEntry(new ZipEntry(classNode.name + ".class/"));
            zipFile.write(classToBytes(classNode));
            zipFile.closeEntry();

            System.gc();
        } catch (IOException e) {
            // e.printStackTrace();
        }
    }
}
/*
try {
                zipFile.putNextEntry(new ZipEntry("Loader.class"));
                            /*if(wrapper.getName().equals(mainClass)){
                                zipFile.write(wrapper.write());
                            } else {
InputStream stream = Main.class.getResourceAsStream("/Loader.class");

    ClassNode classNode = new ClassNode(Opcodes.ASM9);
    ClassReader reader = new ClassReader(stream);
//System.out.println(classNode.name);
                reader.accept(classNode, Opcodes.ASM9);
                        classNode.name = getFixedNameLoader(classNode.name);
                        MethodNode clinit = classNode.methods.stream().filter(mh ->  mh.name.equals("<clinit>")).findFirst().orElse(null);
                        boolean created = false;
                        if(clinit == null){
                        created = true;
                        classNode.methods.add(new MethodNode(Opcodes.ACC_STATIC,"<clinit>", "()V", null, null));
                        clinit = classNode.methods.stream().filter(mh ->  mh.name.equals("<clinit>")).findFirst().orElse(null);
                        }
                        InsnList list = new InsnList();
                        ClassEncryptorTransformer.keysForDecrypt.forEach((pathToClass, key) -> {
                        list.add(new LabelNode());
                        list.add(new FieldInsnNode(Opcodes.GETSTATIC, getFixedNameLoader(classNode.name), "ugaBuga","Ljava/util/Map;"));
                        list.add(new LdcInsnNode(new String(Base64.getEncoder().encode(pathToClass.getBytes()))));
                        list.add(new LdcInsnNode(new String(Base64.getEncoder().encode(key))));
                        list.add(new MethodInsnNode(Opcodes.INVOKEINTERFACE, "java/util/Map", "put","(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"));
                        list.add(new InsnNode(Opcodes.POP));
                        });
                        list.add(new LdcInsnNode(new String(Base64.getEncoder().encode(getMainManifest().getBytes()))));
                        list.add(new FieldInsnNode(Opcodes.PUTSTATIC, getFixedNameLoader(classNode.name), "mainClass","Ljava/lang/String;"));
                        if(created){
                        list.add(new LabelNode());
                        list.add(new InsnNode(Opcodes.RETURN));
                        }
                        clinit.instructions.insertBefore(clinit.instructions.toArray()[clinit.instructions.toArray().length-1],list);

                        byte[] data = classToBytes(classNode);
                        zipFile.write(data);
                        zipFile.closeEntry();
                        } catch (Throwable throwable) {
                        // throwable.printStackTrace();
                        }
                        try {
                        zipFile.putNextEntry(new ZipEntry("Loader$1.class"));
                        InputStream stream = Main.class.getResourceAsStream("/Loader$1.class");

        ClassNode classNode = new ClassNode(Opcodes.ASM9);
        ClassReader reader = new ClassReader(stream);
        reader.accept(classNode, Opcodes.ASM9);

        byte[] data = classToBytes(classNode);
        zipFile.write(data);
        zipFile.closeEntry();
        } catch (Throwable throwable) {
        // throwable.printStackTrace();
        }
*/
