package starlock.utils;

import lombok.NonNull;
import lombok.SneakyThrows;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.tree.ClassNode;
import org.simpleyaml.configuration.file.YamlConfiguration;
import starlock.Main;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Utils {
    private static YamlConfiguration cfg = new YamlConfiguration();
    public static String randomString(int length) {
        String regex = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890";
        char[] chars = regex.toCharArray();
        StringBuilder builder = new StringBuilder();

        for(int i = 0; i < length; ++i) {
            int c = (int)(Math.random() * (double)chars.length);
            builder.append(chars[c]);
        }

        return builder.toString();
    }
    public static String getRandomInvalidString(int length, int repeat) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < repeat; i++) {
            s.append(IntStream.range(0, length)
                    .mapToObj(ii -> Character.toString((char) (new Random()).nextInt(1999999999))
                            .replace(";", "")
                            .replace("/", "")
                            .replace(".", "")
                            .replace("[", ""))
                    .collect(Collectors.joining()));
        }
        return new String(s.toString().getBytes(StandardCharsets.UTF_8));
    }
    public static YamlConfiguration getConfig(){
        try {
            cfg.load(new File("config.yml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return cfg;
    }
    public static void saveCFG(){
        try {
            InputStream cfg = Utils.class.getResourceAsStream("../../config.yml");
            FileOutputStream outputStream = new FileOutputStream("config.yml");
            outputStream.write(cfg.readAllBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static String getMainManifest(){
        byte[] manifestData;
        manifestData = Main.FILES.get("META-INF/MANIFEST.MF");
        if (manifestData == null) return null;

        return Arrays.stream(new String(manifestData).split("\n"))
                .filter(s -> s.startsWith("Main-Class: "))
                .findFirst()
                .orElse("StarLockNotFoundMainInManifest")
                .trim()
                .split(": ")[1]
                .replaceAll("\\.", "/");
    }
    public static byte[] classToBytes(ClassNode classNode) {
        ClassWriter classWriter = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        classNode.accept(classWriter);
        return classWriter.toByteArray();
    }
    public static final String[] colors = new String[]{"31m", "32m", "33m", "34m", "35m", "36m", "37m", "38m", "39m"};
    @SneakyThrows
    public static boolean isClassFile(@NonNull String entryName, byte @NonNull [] buffer) {
        return (entryName.endsWith(".class") && buffer.length >= 4
                        && String.format("%02X%02X%02X%02X", buffer[0], buffer[1], buffer[2], buffer[3]
        ).equalsIgnoreCase("cafebabe"));
    }
}
