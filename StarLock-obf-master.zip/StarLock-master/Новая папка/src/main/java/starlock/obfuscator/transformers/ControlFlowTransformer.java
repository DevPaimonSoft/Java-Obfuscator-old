package starlock.obfuscator.transformers;

import org.objectweb.asm.tree.*;
import starlock.Main;
import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.flow.LightControlFlowTransformer;
import starlock.obfuscator.transformers.impl.ref.HeavyInvokeDynamic;
import starlock.utils.StringUtil;
import starlock.utils.wrapper.ClassWrapper;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class ControlFlowTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        LOGGER.debug("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
        LOGGER.debug("      ControlFlowTransformer running...");
        switch (getConfig().getString("InvokeDynamic.Mode")){
            case "Light" -> new LightControlFlowTransformer().obfuscate(obfuscator);
            case "Medium" -> new LightControlFlowTransformer().obfuscate(obfuscator);
            case "Heavy" -> new LightControlFlowTransformer().obfuscate(obfuscator);
            default -> throw new IllegalArgumentException();
        }
        LOGGER.debug("      ControlFlowTransformer finished!");
        LOGGER.debug("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
    }
}
