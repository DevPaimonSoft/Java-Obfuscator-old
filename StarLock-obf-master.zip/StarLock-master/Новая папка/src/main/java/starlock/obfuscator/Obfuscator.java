package starlock.obfuscator;

import starlock.obfuscator.transformers.*;
import starlock.obfuscator.transformers.impl.flow.LightControlFlowTransformer;
import starlock.utils.ASMHelper;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.util.*;

public class Obfuscator extends ASMHelper {
    private static Obfuscator instance;
    public void run() {
        instance = this;
        new StringTransformer().transform(instance);
        new NumberTransformer().transform(instance);
        //new InvokeDynamicTransformer().transform(instance);
        new ControlFlowTransformer().transform(instance);
        new RenamerTransformer().transform(instance);
    }

    public List<ClassNode> getClasses(){
        List<ClassNode> toReturn = new ArrayList<>();
        CLASSES.forEach(c -> toReturn.add(c.getClassNode()));
        return toReturn;
    }

    private static void processHideCode(ClassNode classNode) {
        classNode.access &= ~(Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
        classNode.access |= (Opcodes.ACC_SYNTHETIC | Opcodes.ACC_PUBLIC);

        classNode.methods.forEach(method -> {
            if (!method.name.equals("<init>") && !method.name.equals("<clinit>")) {
                method.access &= ~(Opcodes.ACC_VARARGS | Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
                method.access |= (Opcodes.ACC_PUBLIC | Opcodes.ACC_SYNTHETIC | Opcodes.ACC_BRIDGE);
            } else {
                method.access &= ~(Opcodes.ACC_VARARGS | Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
                method.access |= (Opcodes.ACC_PUBLIC | Opcodes.ACC_SYNTHETIC);
            }

            //if ((Opcodes.ACC_STATIC & method.access) != 0)
            //    method.access |= (Opcodes.ACC_SYNTHETIC | Opcodes.ACC_BRIDGE);

            if (method.parameters != null)
                for (ParameterNode pn : method.parameters)
                    pn.access |= (Opcodes.ACC_SYNTHETIC);
        });

        classNode.fields.forEach(field -> {
            field.access &= ~(Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
            field.access |= (Opcodes.ACC_SYNTHETIC | Opcodes.ACC_PUBLIC);
        });
    }

    private static byte[] encrypt(byte[] bytes, String klass, String method, String hash, int keyLength) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(hash);
            SecretKeySpec secretKey = new SecretKeySpec(Arrays.copyOf(messageDigest.digest((klass + method).getBytes()), keyLength), "AES");
            Cipher encoder = Cipher.getInstance("AES/ECB/PKCS5Padding");
            encoder.init(Cipher.ENCRYPT_MODE, secretKey);
            return Base64.getEncoder().encode(encoder.doFinal(bytes));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}