package starlock.obfuscator.transformers.impl.renamer;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.RenamerTransformer;

import java.util.Random;

public class LocalVaribleTransformer extends RenamerTransformer {
    public static long obfuscated = 0;

    public void obfuscate(Obfuscator obfuscator){
        obfuscator.getClasses().stream()
                .filter(classNode -> classNode.name.contains("youngsmoke"))
                //.filter(classNode -> (getConfig().getStringList("Renamer.Path").contains(classNode.name)
                //        || getConfig().getStringList("Renamer.Path").contains(classNode.name.replace(".","/"))))
                .forEach(classNode -> {
            classNode.methods.forEach(methodNode -> {
                if(methodNode.localVariables != null){
                    //obfuscated += methodNode.localVariables.size();
                    methodNode.localVariables.forEach(var
                            -> var.name = getRandomInvalidString(new Random().nextInt(50,300),new Random().nextInt(1,3)));
                }
            });
        });
    }
}
