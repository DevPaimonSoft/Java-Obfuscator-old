package starlock.obfuscator.transformers;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.number.MutationNumberTransformer;
import starlock.obfuscator.transformers.impl.ref.HeavyInvokeDynamic;

public class NumberTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        LOGGER.debug("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
        LOGGER.debug("      NumberTransformer running...");
        switch (getConfig().getString("NumberObfuscation.Mode")){
            case "Normal" -> new HeavyInvokeDynamic().obfuscate(obfuscator);
            case "Mutation" -> new MutationNumberTransformer().obfuscate(obfuscator);
            default -> throw new IllegalArgumentException();
        }
        LOGGER.debug("      NumberTransformer finished!");
        //LOGGER.debug("      Obfuscated localVariables: ");
        LOGGER.debug("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
    }
}
