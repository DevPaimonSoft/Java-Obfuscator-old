package starlock.obfuscator;

import org.objectweb.asm.Opcodes;
import starlock.utils.ASMHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class Transformer extends ASMHelper implements Opcodes {

    protected static final Logger LOGGER = LogManager.getLogger("StarLock");
    public abstract void transform(Obfuscator obfuscator);
    public String name() {
        return this.getClass().getSimpleName();
    }
}
