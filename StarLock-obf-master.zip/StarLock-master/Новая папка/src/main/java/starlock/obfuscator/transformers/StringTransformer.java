package starlock.obfuscator.transformers;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.ref.HeavyInvokeDynamic;
import starlock.obfuscator.transformers.impl.renamer.LocalVaribleTransformer;
import starlock.obfuscator.transformers.impl.string.HeavyStringTransformer;

public class StringTransformer  extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        LOGGER.debug("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
        LOGGER.debug("      StringTransformer running...");
        switch (getConfig().getString("StringEncryption.Mode")){
            case "Normal" -> new HeavyStringTransformer().obfuscate(obfuscator);
            case "Heavy" -> new HeavyStringTransformer().obfuscate(obfuscator);
            default -> throw new IllegalArgumentException();
        }
        LOGGER.debug("      StringTransformer finished!");
        LOGGER.debug("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
    }
}