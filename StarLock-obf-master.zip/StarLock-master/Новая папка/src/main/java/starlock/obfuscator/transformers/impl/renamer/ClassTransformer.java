package starlock.obfuscator.transformers.impl.renamer;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.transformers.RenamerTransformer;
import starlock.utils.CustomRemapper;

import java.util.HashMap;
import java.util.Random;

public class ClassTransformer extends RenamerTransformer {

    public void obfuscate(Obfuscator obfuscator){
        CustomRemapper remapper = new CustomRemapper();
        obfuscator.getClasses().stream()
                .filter(classNode -> classNode.name.contains("youngsmoke"))
                .forEach(classNode -> {
                    classNode.methods.stream()
                            .filter(methodNode -> !methodNode.name.equals("<init>"))
                            .filter(methodNode -> !methodNode.name.equals("<clinit>"))
                            .forEach(methodNode -> {
                        remapper.mapMethodName(methodNode.name, getRandomInvalidString(new Random().nextInt(30,100),new Random().nextInt(1,3)), methodNode.desc);
                    });
                });
    }
}
