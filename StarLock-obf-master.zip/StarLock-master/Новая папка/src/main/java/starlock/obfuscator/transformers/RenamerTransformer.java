package starlock.obfuscator.transformers;

import starlock.obfuscator.Obfuscator;
import starlock.obfuscator.Transformer;
import starlock.obfuscator.transformers.impl.renamer.ClassTransformer;
import starlock.obfuscator.transformers.impl.renamer.LocalVaribleTransformer;

public class RenamerTransformer extends Transformer {
    @Override
    public void transform(Obfuscator obfuscator) {
        LOGGER.debug("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
        LOGGER.debug("      RenamerTransformer running...");
        new LocalVaribleTransformer().obfuscate(obfuscator);
        new ClassTransformer().obfuscate(obfuscator);
        LOGGER.debug("      RenamerTransformer finished!");
        LOGGER.debug("      Obfuscated localVariables: " + LocalVaribleTransformer.obfuscated);
        LOGGER.debug("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
    }
}